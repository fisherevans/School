package com.fisherevans.oop.deli.exeps;

public class InvalidOrderNumberExecption extends Exception
{

}
