package com.fisherevans.oop.deli.exeps;

public class EmptyOrderException extends Exception
{

}
