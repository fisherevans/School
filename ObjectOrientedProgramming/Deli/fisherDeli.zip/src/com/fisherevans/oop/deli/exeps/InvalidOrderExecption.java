package com.fisherevans.oop.deli.exeps;

public class InvalidOrderExecption extends Exception
{

}
