package info.fisherevans.school.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class CalculatorActivity extends Activity
{
		// Create the activity and GUI manager
	public GUIManager gui;
	public UserInput userInput;
	public NumberInput numberInput;
	public FunctionInput functionInput;
	public GlobalInput globalInput;
	
		// Create number vars
	public String lastNum, curOp, curNum;
	public boolean curDec,curPos, justEntered;
	
		// Called when the activity is first created.
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.main);
	    
		gui = new GUIManager(this);
		userInput = new UserInput(this);
		numberInput = new NumberInput(this);
		functionInput = new FunctionInput(this);
		globalInput = new GlobalInput(this);
		
		lastNum = "";
		curDec = false;
		curPos = true;
		curOp = "";
		curNum = "";
		justEntered = false;
	}

	public void numberButtonInput(View v)
	{
		if(justEntered)
			globalInput.reset();
		userInput.onNumericalClick(v);
	}
	public void functionButtonInput(View v)
	{
		justEntered = false;
		userInput.onFunctionClick(v);
	}
	public void globalButtonInput(View v)
	{
		justEntered = false;
		userInput.onGlobalClick(v);
	}
}