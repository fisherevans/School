package info.fisherevans.school.calculator;

public class FunctionInput
{
		// App activity and core
	private CalculatorActivity activity;
	
	public FunctionInput(CalculatorActivity activity)
	{
		this.activity = activity;
	}
	
	public void setOp(String nextOp)
	{
		if(!activity.curOp.equals("") && !activity.curNum.equals(""))
			activity.globalInput.equals();
		
		if(activity.curNum.equals("") && !activity.lastNum.equals(""))
			activity.curOp = nextOp;
		else if(!activity.curNum.equals("") && activity.lastNum.equals(""))
		{
			activity.lastNum = activity.curPos ? "" : "-";
			
			activity.lastNum += activity.curNum;
			
			activity.curOp = nextOp;
			
			activity.curNum = "";
			activity.curPos = true;
			activity.curDec = false;
		}
		activity.gui.updateDisplay();
	}
}
