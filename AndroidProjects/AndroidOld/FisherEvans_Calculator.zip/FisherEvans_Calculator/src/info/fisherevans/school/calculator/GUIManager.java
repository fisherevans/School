package info.fisherevans.school.calculator;

import android.widget.TextView;

public class GUIManager
{
	private CalculatorActivity activity;
	
	public TextView lastInput, curInput;
	
	public GUIManager(CalculatorActivity activity)
	{
		this.activity = activity;
		
		initDisplays();
	}
	
	public void initDisplays()
	{
		lastInput = (TextView) activity.findViewById(R.id.lastInput);
		curInput = (TextView) activity.findViewById(R.id.curInput);
	}
	
	public void updateDisplay()
	{
		lastInput.setText(activity.lastNum);
		if(!activity.curOp.equals(""))
			lastInput.setText(lastInput.getText() + " " + activity.curOp);
		
		if(!activity.curPos)
			curInput.setText("-" + activity.curNum);
		else
			curInput.setText(activity.curNum);
	}
}
