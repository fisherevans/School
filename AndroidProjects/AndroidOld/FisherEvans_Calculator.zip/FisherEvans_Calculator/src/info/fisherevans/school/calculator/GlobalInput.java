package info.fisherevans.school.calculator;

public class GlobalInput
{
		// App activity and core
	private CalculatorActivity activity;
	
	public GlobalInput(CalculatorActivity activity)
	{
		this.activity = activity;
	}
	
	public void equals()
	{
		if(!activity.curOp.equals("") && !activity.curNum.equals(""))
		{
			double lastNum = Double.parseDouble(activity.lastNum);
			double curNum = Double.parseDouble(activity.curNum);
			double newNum = 0;
			boolean knownOp = true;
			
			if(!activity.curPos)
				curNum *= -1.0;
			
			if(activity.curOp.equals("+"))
			{
				newNum = lastNum + curNum;
			}
			else if(activity.curOp.equals("-"))
			{
				newNum = lastNum - curNum;
			}
			else if(activity.curOp.equals("/"))
			{
				newNum = lastNum / curNum;
			}
			else if(activity.curOp.equals("*"))
			{
				newNum = lastNum * curNum;
			}
			else if(activity.curOp.equals("^"))
			{
				newNum = Math.pow(lastNum,curNum);
			}
			else
			{
				reset();
				knownOp = false;
			}
			
			if(knownOp)
			{
				boolean nextPos = newNum < 0 ? false : true;
				boolean nextDec = newNum == (int)newNum ? false : true;
				
				activity.lastNum = "";
				if(!nextDec)
					activity.curNum = "" + (int)(Math.abs(newNum));
				else
					activity.curNum = "" + (Math.abs(newNum));
				activity.curPos = nextPos;
				activity.curDec = nextDec;
				activity.curOp = "";
			}
			activity.justEntered = true;
			activity.gui.updateDisplay();
		}
	}
	
	public void percent()
	{
		equals();
		
		double newNum = Double.parseDouble(activity.curNum) * 100.0;
		
		reset();
		
		if(newNum < 0)
		{
			activity.curPos = false;
		}
		
		if((int)newNum == newNum)
		{
			activity.curNum = (int)newNum + "";
		}
		else
		{
			activity.curNum = newNum + "";
		}
		activity.gui.updateDisplay();
	}
	
	public void recip()
	{
		equals();
		
		double newNum = 1.0 / Double.parseDouble(activity.curNum);
		
		reset();
		
		if(newNum < 0)
		{
			activity.curPos = false;
		}
		
		if((int)newNum == newNum)
		{
			activity.curNum = (int)newNum + "";
		}
		else
		{
			activity.curNum = newNum + "";
		}
		activity.gui.updateDisplay();
	}
	
	public void sqrt()
	{
		equals();
		
		String signLead = activity.curPos ? "" : "-";
		
		double newNum = Math.sqrt(Double.parseDouble(signLead + activity.curNum));
		
		reset();
		
		if(newNum < 0)
		{
			activity.curPos = false;
		}
		
		if((int)newNum == newNum)
		{
			activity.curNum = (int)newNum + "";
		}
		else
		{
			activity.curNum = newNum + "";
		}
		activity.gui.updateDisplay();
	}
	
	public void reset()
	{
		activity.curNum = "0";
		activity.curPos = true;
		activity.curDec = false;
		activity.curOp = "";
		activity.lastNum = "";
		activity.justEntered = false;
		activity.gui.updateDisplay();
	}
}
